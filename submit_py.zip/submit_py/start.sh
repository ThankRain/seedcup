chmod +x bot
./bot